package com.tp.jpa;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Date;

import com.tp.jpa.entities.Articulo;
import com.tp.jpa.entities.Cliente;
import com.tp.jpa.entities.CondicionIva;
import com.tp.jpa.entities.Contacto;
import com.tp.jpa.entities.Domicilio;
import com.tp.jpa.entities.FacturaVenta;
import com.tp.jpa.entities.FacturaVentaDetalle;
import com.tp.jpa.entities.ListaPrecio;
import com.tp.jpa.entities.ListaPrecioArticulo;
import com.tp.jpa.entities.Marca;
import com.tp.jpa.entities.PuntoVenta;
import com.tp.jpa.entities.Rubro;
import com.tp.jpa.entities.TipoMoneda;
import com.tp.jpa.entities.Usuario;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Main {

    public static void main(String[] args) {
        // Usamos directamente la unidad de persistencia de tu persistence.xml
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("FacturacionPU");
        EntityManager em = emf.createEntityManager();

        try {
            em.getTransaction().begin();
            cargarDatosPrueba(em);
            em.getTransaction().commit();

            System.out.println("\n=============================================");
            System.out.println("       EJECUTANDO CONSULTAS JPQL            ");
            System.out.println("=============================================\n");

            // --- EJECUCIÓN DE LAS 20 CONSULTAS JPQL ---
            ConsultasJPQL.ej01_todasLasFacturas(em);
            ConsultasJPQL.ej02_proyeccionFacturas(em);
            ConsultasJPQL.ej03_articulosPorRubro(em, "Tecnología");
            ConsultasJPQL.ej04_facturasPorRangoFechas(em, LocalDate.now().minusDays(30), LocalDate.now().plusDays(1));
            ConsultasJPQL.ej05_facturasEmitidasValidas(em);
            ConsultasJPQL.ej06_buscarClientes(em, "Cliente");
            ConsultasJPQL.ej07_estadosSinDuplicados(em);
            ConsultasJPQL.ej08_estadisticasFacturas(em);
            ConsultasJPQL.ej09_puntosVentaIn(em, Arrays.asList(1, 2));
            ConsultasJPQL.ej10_facturasPorUsuario(em, "admin");
            ConsultasJPQL.ej11_detallesPorPuntoVenta(em, 1);
            ConsultasJPQL.ej12_articulosYMarcas(em);
            ConsultasJPQL.ej13_facturasPorMarcaArticulo(em, "Logitech");
            ConsultasJPQL.ej14_facturasSobreElPromedio(em);
            ConsultasJPQL.ej15_resumenPorPuntoVenta(em);
            ConsultasJPQL.ej16_usuariosConMasDe5Facturas(em);
            ConsultasJPQL.ej17_ventasPorMarca(em);
            ConsultasJPQL.ej18_marcasVendidas(em);
            ConsultasJPQL.ej19_articulosSinVender(em);
            ConsultasJPQL.ej20_clasificacionFacturas(em);

            System.out.println("\n=============================================\n");

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }

    private static void cargarDatosPrueba(EntityManager em) {
        Date ahora = new Date();

        // 1. Usuarios
        Usuario uAdmin = new Usuario();
        uAdmin.setUsuario("admin");
        uAdmin.setNombre("Carlos");
        uAdmin.setApellido("Pérez");
        uAdmin.setClave("1234");
        em.persist(uAdmin);

        Usuario uVendedor = new Usuario();
        uVendedor.setUsuario("vendedor1");
        uVendedor.setNombre("Ana");
        uVendedor.setApellido("Gómez");
        uVendedor.setClave("1234");
        em.persist(uVendedor);

        // 2. Puntos de Venta
        PuntoVenta pv1 = new PuntoVenta();
        pv1.setNumero(1);
        pv1.setDescripcion("Sucursal Central");
        pv1.setTipoEmision("Electrónica");
        pv1.setDomicilioComercial("Av. San Martín 123");
        pv1.setFechaAlta(ahora);
        pv1.setFechaModificacion(ahora);
        pv1.setUsuarioCarga(uAdmin);
        pv1.setUsuarioModificacion(uAdmin);
        em.persist(pv1);

        PuntoVenta pv2 = new PuntoVenta();
        pv2.setNumero(2);
        pv2.setDescripcion("Sucursal Norte");
        pv2.setTipoEmision("Electrónica");
        pv2.setDomicilioComercial("Av. Las Heras 456");
        pv2.setFechaAlta(ahora);
        pv2.setFechaModificacion(ahora);
        pv2.setUsuarioCarga(uAdmin);
        pv2.setUsuarioModificacion(uAdmin);
        em.persist(pv2);

        // 3. Rubros
        Rubro rTecno = new Rubro();
        rTecno.setCodigo(100);
        rTecno.setDenominacion("Tecnología");
        rTecno.setFechaAlta(ahora);
        rTecno.setFechaModificacion(ahora);
        rTecno.setUsuarioCarga(uAdmin);
        rTecno.setUsuarioModificacion(uAdmin);
        em.persist(rTecno);

        Rubro rHogar = new Rubro();
        rHogar.setCodigo(200);
        rHogar.setDenominacion("Hogar");
        rHogar.setFechaAlta(ahora);
        rHogar.setFechaModificacion(ahora);
        rHogar.setUsuarioCarga(uAdmin);
        rHogar.setUsuarioModificacion(uAdmin);
        em.persist(rHogar);

        // 4. Marcas
        Marca mLogitech = new Marca();
        mLogitech.setCodigo(10);
        mLogitech.setDenominacion("Logitech");
        mLogitech.setFechaAlta(ahora);
        mLogitech.setFechaModificacion(ahora);
        mLogitech.setUsuarioCarga(uAdmin);
        mLogitech.setUsuarioModificacion(uAdmin);
        em.persist(mLogitech);

        Marca mSamsung = new Marca();
        mSamsung.setCodigo(20);
        mSamsung.setDenominacion("Samsung");
        mSamsung.setFechaAlta(ahora);
        mSamsung.setFechaModificacion(ahora);
        mSamsung.setUsuarioCarga(uAdmin);
        mSamsung.setUsuarioModificacion(uAdmin);
        em.persist(mSamsung);

        Marca mSony = new Marca(); // Marca para articulos sin vender
        mSony.setCodigo(30);
        mSony.setDenominacion("Sony");
        mSony.setFechaAlta(ahora);
        mSony.setFechaModificacion(ahora);
        mSony.setUsuarioCarga(uAdmin);
        mSony.setUsuarioModificacion(uAdmin);
        em.persist(mSony);

        // 5. Contacto, Domicilio y Cliente
        Contacto con = new Contacto();
        con.setEmail("contacto@cliente.com");
        con.setCelular("2611234567");
        con.setTelefono("011-4444-5555");

        Domicilio dom = new Domicilio();
        dom.setNombreCalle("Calle Falsa");
        dom.setNumeroCalle("123");

        Cliente cli = new Cliente();
        cli.setDenominacion("Empresa Cliente S.A.");
        cli.setCuitCuil("20-30405060-8");
        cli.setContacto(con);
        cli.setDomicilio(dom);
        cli.setFechaAlta(ahora);
        cli.setFechaModificacion(ahora);
        cli.setUsuarioCarga(uAdmin);
        cli.setUsuarioModificacion(uAdmin);
        em.persist(cli);

        CondicionIva condIva = new CondicionIva();
        condIva.setCodigoAfip(1);
        condIva.setDenominacion("Responsable Inscripto");
        condIva.setFechaAlta(ahora);
        condIva.setFechaModificacion(ahora);
        condIva.setUsuarioCarga(uAdmin);
        condIva.setUsuarioModificacion(uAdmin);
        em.persist(condIva);

        TipoMoneda moneda = new TipoMoneda();
        moneda.setCodigoAfip("PES");
        moneda.setDenominacion("Pesos Argentinos");
        moneda.setSimbolo("$");
        moneda.setFechaAlta(ahora);
        moneda.setFechaModificacion(ahora);
        moneda.setUsuarioCarga(uAdmin);
        moneda.setUsuarioModificacion(uAdmin);
        em.persist(moneda);

        // 6. Artículos y Lista de Precios
        Articulo artMouse = new Articulo();
        artMouse.setCodigo("A001");
        artMouse.setDenominacion("Mouse Inalámbrico MX Master 3");
        artMouse.setRubro(rTecno);
        artMouse.setMarca(mLogitech);
        artMouse.setFechaAlta(ahora);
        artMouse.setFechaModificacion(ahora);
        artMouse.setUsuarioCarga(uAdmin);
        artMouse.setUsuarioModificacion(uAdmin);
        em.persist(artMouse);

        Articulo artMonitor = new Articulo();
        artMonitor.setCodigo("A002");
        artMonitor.setDenominacion("Monitor Curvo 27'");
        artMonitor.setRubro(rTecno);
        artMonitor.setMarca(mSamsung);
        artMonitor.setFechaAlta(ahora);
        artMonitor.setFechaModificacion(ahora);
        artMonitor.setUsuarioCarga(uAdmin);
        artMonitor.setUsuarioModificacion(uAdmin);
        em.persist(artMonitor);

        Articulo artSinVender = new Articulo(); // Para EJ 19
        artSinVender.setCodigo("A003");
        artSinVender.setDenominacion("Auriculares Bluetooth Sony");
        artSinVender.setRubro(rTecno);
        artSinVender.setMarca(mSony);
        artSinVender.setFechaAlta(ahora);
        artSinVender.setFechaModificacion(ahora);
        artSinVender.setUsuarioCarga(uAdmin);
        artSinVender.setUsuarioModificacion(uAdmin);
        em.persist(artSinVender);

        ListaPrecio lp = new ListaPrecio();
        lp.setCodigo("L01");
        lp.setDenominacion("Lista General");
        lp.setFechaAlta(ahora);
        lp.setFechaModificacion(ahora);
        lp.setUsuarioCarga(uAdmin);
        lp.setUsuarioModificacion(uAdmin);
        em.persist(lp);

        ListaPrecioArticulo lpaMouse = new ListaPrecioArticulo();
        lpaMouse.setArticulo(artMouse);
        lpaMouse.setListaPrecio(lp);
        lpaMouse.setPrecioVenta(15000.0);
        lpaMouse.setFechaAlta(ahora);
        lpaMouse.setFechaModificacion(ahora);
        lpaMouse.setUsuarioCarga(uAdmin);
        lpaMouse.setUsuarioModificacion(uAdmin);
        em.persist(lpaMouse);

        ListaPrecioArticulo lpaMonitor = new ListaPrecioArticulo();
        lpaMonitor.setArticulo(artMonitor);
        lpaMonitor.setListaPrecio(lp);
        lpaMonitor.setPrecioVenta(75000.0);
        lpaMonitor.setFechaAlta(ahora);
        lpaMonitor.setFechaModificacion(ahora);
        lpaMonitor.setUsuarioCarga(uAdmin);
        lpaMonitor.setUsuarioModificacion(uAdmin);
        em.persist(lpaMonitor);

        ListaPrecioArticulo lpaSinVender = new ListaPrecioArticulo();
        lpaSinVender.setArticulo(artSinVender);
        lpaSinVender.setListaPrecio(lp);
        lpaSinVender.setPrecioVenta(40000.0);
        lpaSinVender.setFechaAlta(ahora);
        lpaSinVender.setFechaModificacion(ahora);
        lpaSinVender.setUsuarioCarga(uAdmin);
        lpaSinVender.setUsuarioModificacion(uAdmin);
        em.persist(lpaSinVender);

        // 7. Generación de 6 Facturas para uAdmin (para cumplir EJ 16 > 5 facturas)
        double[] montos = {8000.0, 15000.0, 30000.0, 55000.0, 90000.0, 120000.0};

        for (int i = 0; i < montos.length; i++) {
            FacturaVenta f = new FacturaVenta();
            f.setNumero((long) (1001 + i));
            f.setFechaEmision(ahora);
            f.setEstado("EMITIDA");
            f.setImporteTotal(montos[i]);
            f.setImporteCobrado(montos[i]);
            f.setImporteSaldo(0.0);
            f.setPuntoVenta(i % 2 == 0 ? pv1 : pv2);
            f.setCliente(cli);
            f.setCondicionIva(condIva);
            f.setTipoMoneda(moneda);
            f.setFechaAlta(ahora);
            f.setFechaModificacion(ahora);
            f.setUsuarioCarga(uAdmin);
            f.setUsuarioModificacion(uAdmin);

            FacturaVentaDetalle det = new FacturaVentaDetalle();
            det.setListaPrecioArticulo(i % 2 == 0 ? lpaMouse : lpaMonitor);
            det.setDescripcion(i % 2 == 0 ? "Mouse MX Master 3" : "Monitor Curvo 27'");
            det.setCantidad(1.0);
            det.setPrecioUnitario(montos[i]);
            det.setImporteSubtotal(montos[i]);
            det.setImporteNeto(montos[i] * 0.83);
            det.setImporteIva(montos[i] * 0.17);

            f.addDetalle(det);
            em.persist(f);
        }

        // Factura adicional para uVendedor
        FacturaVenta fExtra = new FacturaVenta();
        fExtra.setNumero(2001L);
        fExtra.setFechaEmision(ahora);
        fExtra.setEstado("EMITIDA");
        fExtra.setImporteTotal(25000.0);
        fExtra.setImporteCobrado(25000.0);
        fExtra.setImporteSaldo(0.0);
        fExtra.setPuntoVenta(pv1);
        fExtra.setCliente(cli);
        fExtra.setCondicionIva(condIva);
        fExtra.setTipoMoneda(moneda);
        fExtra.setFechaAlta(ahora);
        fExtra.setFechaModificacion(ahora);
        fExtra.setUsuarioCarga(uVendedor);
        fExtra.setUsuarioModificacion(uVendedor);

        FacturaVentaDetalle detExtra = new FacturaVentaDetalle();
        detExtra.setListaPrecioArticulo(lpaMouse);
        detExtra.setDescripcion("Mouse MX Master 3");
        detExtra.setCantidad(2.0);
        detExtra.setPrecioUnitario(12500.0);
        detExtra.setImporteSubtotal(25000.0);
        detExtra.setImporteNeto(20750.0);
        detExtra.setImporteIva(4250.0);

        fExtra.addDetalle(detExtra);
        em.persist(fExtra);
    }
}